# GYEOMS Foundation Working Draft — 260709_vibe-diagnosis

## 현재 목적
이 문서는 새 대화창에서 `260709_vibe-diagnosis` 작업을 즉시 이어가기 위한 Foundation Working Draft입니다.

## 프로젝트 정체성
`vibe-diagnosis`는 바이브코딩 프로젝트에서 AI 에이전트가 수행한 작업을 `.diag.js` 진단 파일로 검증하고, 결과를 CLI/MCP/웹 대시보드/VS Code 확장으로 확인하게 하는 자가진단 프레임워크입니다.

핵심 원칙:
> Task ↔ Diagnostic 1:1 Mapping

## 현재 저장소 상태
- Repository: https://github.com/gyeoms-vibe/260709_vibe-diagnosis
- Branch: main
- GitHub page observed: Public repository, 4 commits.
- User-reported commits:
  - `98655e6`: first push with code cleanup/issue fixes/tests, VSIX artifacts excluded.
  - `8cd3097`: package metadata and README URL cleanup.
  - `e929a5b`: implementation_plan management note + Credits.
- Current web-verified metadata:
  - root package `vibe-diagnosis` v1.1.0.
  - MCP package `vibe-diagnosis-mcp` v1.1.0 with dependency `vibe-diagnosis` `^1.1.0`.
  - VS Code extension publisher `gyeoms-vibe`.
  - Rejard preserved as contributor/original author in metadata/credits.
  - License Apache-2.0.

## 작업 이력 요약
1. alopop guide summary.
2. Rejard GitHub repository analysis.
3. User constraint correction: no judging, no unsolicited safety advice.
4. ZIP full analysis and correction of missing root files.
5. Claude Code and Antigravity reports integrated.
6. User-approved VSIX deletion.
7. External agent reported fixes/push.
8. Metadata/credits updates completed and pushed.
9. This Evidence Pack generated for next-conversation continuity.

## 증거 경계
- Included full binary source: original uploaded `260709_vibe-diagnosis.zip`.
- Included current final state evidence: GitHub web snapshot and selected raw package/plan data.
- Not included: fresh full archive/clone of final GitHub main branch.
- Not available: DOCX sources mentioned in target template.

## 상속 제약
- Korean-first.
- Do not judge the artifact.
- Do not add unsolicited safety recommendations.
- Use source-backed status language.
- Do not overstate verification.

## 다음 대화에서 우선 열 파일
1. `NEXT_CONVERSATION_PROMPT.md`
2. `HANDOFF_SPECIFICATION.json`
3. `SOURCE_MANIFEST.json`
4. `CLAIM_MAPPING.json`
5. `CONTRADICTION_LEDGER.json`
6. `source_files/015_current_conversation_refined_log.md`

## pass_to_next_step
새 대화에서는 이 EP를 업로드한 뒤 `NEXT_CONVERSATION_PROMPT.md` 내용을 첫 메시지로 보내면 된다.
