# GitHub Current Repository Web Snapshot

Generated from web verification during Evidence Pack creation.

Repository URL:
https://github.com/gyeoms-vibe/260709_vibe-diagnosis

Observed public repository facts:
- Owner/repository: gyeoms-vibe/260709_vibe-diagnosis
- Public repository.
- Branch shown: main.
- GitHub page showed 4 commits.
- Repository file listing included: .gemini, .vibe-diagnosis/diagnostics, bin, examples/calculator, mcp-server, src, templates, test, vscode-extension, .gitignore, LICENSE, README.ko.md, README.md, implementation_plan.md, package.json.
- README title: vibe-diagnosis.
- README description: Self-diagnosis framework for vibe coding projects.
- README states Task ↔ Diagnostic 1:1 Mapping.
- README describes MCP config with `args`: ["-y", "vibe-diagnosis-mcp"].
- README describes CLI commands: init, run, run --json, dashboard, config get/set, repair.
- README notes `init` creates/updates `.gemini/settings.json` and adds `.vibe-diagnosis/config.json` to `.gitignore`.
- README describes optional per-diagnostic `timeout`, default `30000`.
- README output example shows Vibe Diagnosis v1.1.0.
- README states dashboard binds to 127.0.0.1 only.
- README Development section lists `npm test`, `npm run test:self`, `npm run test:example`.

Raw GitHub package metadata fetched:
- root package: name vibe-diagnosis, version 1.1.0, scripts include node --test "test/*.test.js"; repository/homepage/bugs point to gyeoms-vibe/260709_vibe-diagnosis; author field observed as gyeoms-vibe; contributors include Rejard; license Apache-2.0.
- mcp-server package: name vibe-diagnosis-mcp, version 1.1.0, dependency vibe-diagnosis ^1.1.0; repository directory mcp-server.
- vscode-extension package: name vibe-diagnosis-vscode, version 1.1.0, publisher gyeoms-vibe, contributors include Rejard, bugs URL present.
- implementation_plan.md contains a note referencing current maintained repository and a Credits section listing Original author Rejard and Current maintainer gyeoms-vibe.

Citations in assistant final response should use web references from the active conversation:
- GitHub repository page: turn615357view0
- raw root package.json: turn188990view0
- raw mcp-server/package.json: turn188990view1
- raw vscode-extension/package.json: turn188990view2
- raw implementation_plan.md: turn188990view3

Generated at: 2026-07-09T09:34:16.686266+00:00
